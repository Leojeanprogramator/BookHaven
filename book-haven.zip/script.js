const livros = [...] // código JS completo omitido aqui por tamanho

window.onload = () => {
  mostrarPagina(1);
};